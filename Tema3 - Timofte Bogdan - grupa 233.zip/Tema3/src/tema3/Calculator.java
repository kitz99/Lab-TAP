package tema3;

/**
 * @author Bogdan aka SK
 */
public interface Calculator {
    public double adunare(double x, double y);
    public double scadere(double x, double y);
    public double produs (double x, double y);
    public double cat (double x, double y); 
}
