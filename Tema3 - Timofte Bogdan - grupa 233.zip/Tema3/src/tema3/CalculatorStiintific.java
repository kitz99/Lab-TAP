package tema3;
/**
 *
 * @author Bogdan aka SK;
 */
public interface CalculatorStiintific extends Calculator {
    public double radical(double x);
    public double putere (double x, double y);
}
